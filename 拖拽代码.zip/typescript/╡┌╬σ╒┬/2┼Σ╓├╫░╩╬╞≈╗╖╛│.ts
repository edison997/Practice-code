function decorator(target:object) {}
@decorator

class User{}