var sd = { name: 'zs', age: 11, show: function () { return 'zs'; }, isAdmin: false, sex: 'girl', fly: 9999 };
{
    var Per = /** @class */ (function () {
        function Per() {
            this.name = 'zs';
            this.age = 42;
            // constructor(age: number, name: string) {
            //     this.name = name
            //     this.age = age
            // }
        }
        return Per;
    }());
    // type allbool = bool | bool1  /*使用其中一个就行了*/
    var hd = { name: 'zs', age: 10 };
    var p = /** @class */ (function () {
        function p() {
            this.name = 'zs';
            this.age = 11;
        }
        return p;
    }());
    var hh = {
        name: 'zs',
        age: 12
    };
}
